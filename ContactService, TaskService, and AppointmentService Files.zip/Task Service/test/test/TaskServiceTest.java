// @author Micheal White
// @Date: May 27, 2023
// CS-320-T5519
package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

import task.Task;
import task.TaskService;

class TaskServiceTest {
	
	// To test the TaskService class
		// Tests to add, delete, and update tasks
	    // Task test templates
	    /*
	    * Task("1234567890", "Hank Hill", "A purveyor of propane and propane product");
	      Task("2460100", "Homer Simpson", "Husband, father of 3, and a nuclear safety tech");
	      Task("0000001", "Henry Creel", "First inhabitant of The Upside Down");
	    */

	@Test
    public void testAdd() {
        TaskService ts = new TaskService();
        Task test1 = new Task("1234567890", "Hank Hill", "A purveyor of propane and propane product");
        assertEquals(true, ts.addTask(test1));
    }
	
	@Test
    public void testDelete() {
        TaskService ts = new TaskService();

        Task test1 = new Task("1234567890", "Hank Hill", "A purveyor of propane and propane product");
        Task test2 = new Task("2460100", "Homer Simpson", "Husband, father of 3, and a nuclear safety tech");
        Task test3 = new Task("0000001", "Henry Creel", "First inhabitant of The Upside Down");
        
        ts.addTask(test1);
        ts.addTask(test2);
        ts.addTask(test3);

        assertEquals(true, ts.deleteTask("1234567890"));
        assertEquals(false, ts.deleteTask("1234567899"));
        assertEquals(false, ts.deleteTask("1234567890"));
	}
	
	@Test
    public void testUpdate() {
        TaskService cs = new TaskService();

        Task test1 = new Task("1234567890", "Hank Hill", "A purveyor of propane and propane product");
        Task test2 = new Task("2460100", "Homer Simpson", "Husband, father of 3, and a nuclear safety tech");
        Task test3 = new Task("0000001", "Henry Creel", "First inhabitant of The Upside Down");

        cs.addTask(test1);
        cs.addTask(test2);
        cs.addTask(test3);

        assertEquals(true, cs.updateTask("1234567890", "Hank Rutherford Hill I", "A purveyor of propane and propane product"));
        assertEquals(false, cs.updateTask("14238675309", "Hank Rutherford Hill I", "A purveyor of propane and propane product"));
    }

}
