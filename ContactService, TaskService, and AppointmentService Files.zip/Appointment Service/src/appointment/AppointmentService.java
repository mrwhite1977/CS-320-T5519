package appointment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AppointmentService {
	
	final private List<Appointment> appointmentList = new ArrayList<>();
	
	private String newUniqueId() {return UUID.randomUUID().toString().substring(0, Math.min(toString().length(), 10));
	}
	
	public void newAppointment() {
		Appointment appt = new Appointment(newUniqueId());
		appointmentList.add(appt);
	}

	public void newAppointment(Date date) {
		Appointment appt = new Appointment(newUniqueId(), date);
		appointmentList.add(appt);
	}
	
	public void newAppointment(Date date, String description) {
		Appointment appt = new Appointment(newUniqueId(), date, description);
		appointmentList.add(appt);
	}
	public void deleteAppointment(String id) throws Exception {
		appointmentList.remove(searchForAppointment(id));
	}
	
	public List<Appointment> getAppointmentList() {
		return appointmentList;
	}
	
	private Appointment searchForAppointment(String id) throws Exception {
		int index = 0;
		while (index < appointmentList.size()) {
			if (id.equals(appointmentList.get(index).getAppointmentId())) {
				return appointmentList.get(index);
				
			}
			index++;
		}
		
		throw new Exception("The appointment does not exist!");
	}
	
}
	








/* Getter for  appointment list
	public List<Appointment> getListOfAppointment() {
		return appointmentList;
	}
	
	// Add appointment to list
	public void addAppt(Date date, String description) {
		Appointment appt = new Appointment(newUniqueId(), date, description);
		appointmentList.add(appt);
	}
	
	// Delete appointment to list
	public void deleteAppt(String appointmentId) throws Exception {
		appointmentList.remove(searchForAppointment(appointmentId));
	}
	
	public List<Appointment> getAppointmentList() {
		return appointmentList;
	}
	
	public Appointment searchForAppointment(String id) {
		int index = 0;
		Appointment localList = null;
		while (index < appointmentList.size()) {
			
			if (id.equals(appointmentList.get(index).getAppointmentId())) {
				localList = appointmentList.get(index);
				}
			
			index++;}return localList;
			}
	
	// Updating the name or description
	public void updateDate(String apptId, Date apptDate) {
		try {
			searchForAppointment(apptId).setAppointmentDate(apptDate);
		}
		catch (Exception e) {e.printStackTrace();
		}
	}
	
	public void updateDescription(String apptId, String apptDescript) {
		try {
			searchForAppointment(apptId).setDescription(apptDescript);
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
	

	/* Create array to hold list of appointments
	private ArrayList<Appointment> appointmentList;

		
	public AppointmentService() {
		appointmentList = new ArrayList<>();
			}
	
	// Adding a appointment
	public boolean addAppointment(Appointment appointment) {
	boolean appointmentExist = false;
					
		// Checks if appointment exist
		for(Appointment l:appointmentList) {
			if(l.equals(appointment)) {
				appointmentExist = true; 
			}
		}
					
		// If no appointment exists, one will be added
		if(!appointmentExist) {
			appointmentList.add(appointment);
			return true;
		}
				
		else {
			return false;
		} 
	}
	
	// Deleting an appointment
			public boolean deleteAppointment(String appointmentId) {
				
			//	Check if appointment ID exist. If so, will remove and return
			for(Appointment l:appointmentList) {
				if(l.getAppointmentId().equals(appointmentId)) {
					appointmentList.remove(l);
					return true;
				}
			}
				
			// Otherwise will return false
			return false;
		} */
