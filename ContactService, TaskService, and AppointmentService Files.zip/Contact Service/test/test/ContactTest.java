package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contacts.Contact;

public class ContactTest {
    /*
     * Tests to check whether firstName, lastName, Number, and Address meet 
     * project requirements
     * The first 5 tests check that each field does not become longer than the limit
     * (10 characters for first and last name, exactly 10 characters for phone number,
     * and 30 characters for the address).
     * The last 4 tests ensure that each field is not null.
     * ContactID is not tested for being not null since you cannot create a contactID
     * that is null. Also, each contactID is unique and cannot be updated.
     * Thus, contactID is not tested to be updated.
     */
	
    @Test
    void testContact() {
        Contact contact = new Contact("2460100", "Homer", "Simpson", "3056838353", "742 Evergreen Terrace");
        assertTrue(contact.getContactId().equals("2460100"));
        assertTrue(contact.getFirstName().equals("Homer"));
        assertTrue(contact.getLastName().equals("Simpson"));
        assertTrue(contact.getnumber().equals("3056838353"));
        assertTrue(contact.getaddress().equals("742 Evergreen Terrace"));
    }

    @Test
    void ContactIdTooLong( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100987654","Homer", "Simpson", "3056838353", "742 Evergreen Terrace");
    	});
    }
    
    @Test
    void ContactIdIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact(null,"Homer Simpson", "Simpson", "3056838353", "742 Evergreen Terrace");
    	});
    }
    
    @Test
    void ContactFirstNameTooLong( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100","Homer Simpson", "Simpson", "3056838353", "742 Evergreen Terrace");
    	});
    }
    
    @Test
    void ContactFirstNameIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100",null, "Simpson", "3056838353", "742 Evergreen Terrace");
    	});
    }
    
    @Test
    void ContactLastNameTooLong( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100","Homer", "Jingleheimerschmidt", "3056838353", "742 Evergreen Terrace");
    	});
    }
    
    @Test
    void ContactLastNameIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100", "Homer", null, "3056838353", "742 Evergreen Terrace");
    	});
    }
    
    @Test
    void ContactNumberTooLong( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100","Homer", "Simpson", "3056838353573950", "742 Evergreen Terrace");
    	});
    }
    
    @Test
    void ContactNumberIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100", "Homer", "Simpson", null, "742 Evergreen Terrace");
    	});
    }
    
    @Test
    void ContactAddressTooLong( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100","Homer", "Simpsonian", "3056838353", "742 Evergreen Terrace Roundabout Loop");
    	});
    }
    
    @Test
    void ContactAddressIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Contact("2460100", "Homer", "Simpson", "3056838353", null);
    	});
    }

}