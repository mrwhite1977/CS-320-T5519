// @author Micheal White
// @Date: May 27, 2023
// CS-320-T5519
package task;

public class Task {
	
	private String taskId;
	private String name;
	private String description;
	
	// The requirements for taskId to not be null and not be more than 10 characters in length
	// Otherwise, an exception will be thrown
	public Task(String taskId, String name, String description) {
		if(taskId == null || taskId.length() > 10) {
			// This will test for task ID exception
			throw new IllegalArgumentException("Invalid input");
		}
		
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid name");
		}
			
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		} 
		
		this.taskId = taskId;
		this.name = name;
		this.description = description;
	}
	
	// Create getter and setter for task Id
	public String getTaskId() {
		return taskId;
	}
	
	public void setTaskId(String taskId) { 
		this.taskId = taskId;
	} 
	
	// Create getter and setter for name
	public String getName() {
		return name;
	}
	
	public void setName(String name) { 
		this.name = name;
	} 
	
	// Create getter and setter for description
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) { 
		this.description = description;
	}

}
