package test;

public @interface BeforeEach {

}
