// @author Micheal White
// @Date: May 27, 2023
// CS-320-T5519
package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;

import task.Task;

class TaskTest {
	
	@BeforeAll
	public static void initiateTest() {
		
	}
    
    @AfterAll
    public static void clearTest() {
    	
    }
	
	@Test
	void testTask() {
		Task task = new Task("1234567890", "Student", "Description of the student and their id number now");
		assertTrue(task.getTaskId().equals("1234567890"));
		assertTrue(task.getName().equals("Student"));
		assertTrue(task.getDescription().equals("Description of the student and their id number now"));
	}
	
	@Test
	void testTaskIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Task("12345678909", "Student", "Description of the student and their id number now");
		});
	}
	
	@Test
    void testTaskIdIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Task(null, "Student", "Description of the student and their id number now");
    	});
	}
	
	@Test
	void testNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Task("1234567890", "JohnJacobJingleheimer", "Description of the student and their id number now");
		});
	}
	
	@Test
    void testNameIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Task("1234567890", null, "Description of the student and their id number now");
    	});
	}
	
	@Test
	void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Task("1234567890", "Student", "Description of the student and their id number now!");
		});
	}
	
	@Test
    void testDescriptionIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Task("1234567890","Student", null);
    	});
	}
}

