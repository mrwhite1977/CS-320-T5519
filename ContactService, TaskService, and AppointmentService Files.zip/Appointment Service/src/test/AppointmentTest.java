package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

import appointment.Appointment;

class AppointmentTest {
	
	// Creating Date variables for current, future, and past dates
	private String id, description;
	private String tooLongId, tooLongDescription;
	private Date date, pastDate;

	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() {
		id = "1234567890";
		description = "This appointment is a valid appointment.";
		date = new Date(3021, Calendar.JANUARY, 1);
		tooLongId = "111222333444555666777888999";
		tooLongDescription ="This description is too long for the appointment requirement and should throw an exception.";
		pastDate = new Date(0);
	}
	
	@Test
	void testUpdateAppointmentId() {
		Appointment appt = new Appointment();assertThrows(IllegalArgumentException.class,() -> appt.updateAppointmentId(null));
		assertThrows(IllegalArgumentException.class,() -> appt.updateAppointmentId(tooLongId));
		appt.updateAppointmentId(id);
		assertEquals(id, appt.getAppointmentId());
	}
	
	@Test
	void testGetAppointmentId() {
		Appointment appt = new Appointment(id);
		assertNotNull(appt.getAppointmentId());
		assertEquals(appt.getAppointmentId().length(), 10);
		assertEquals(id, appt.getAppointmentId());
	}
	
	@Test
	void testUpdateDate() {
		Appointment appt = new Appointment();
		assertThrows(IllegalArgumentException.class, () -> appt.updateDate(null));
		assertThrows(IllegalArgumentException.class,() -> appt.updateDate(pastDate));
		appt.updateDate(date);assertEquals(date, appt.getAppointmentDate());
	}
	
	@Test
	void testGetAppointmentDate() {
		Appointment appt = new Appointment(id, date);
		assertNotNull(appt.getAppointmentDate());
		assertEquals(date, appt.getAppointmentDate());
	}
	
	@Test
	void testUpdateDescription() {
		Appointment appt = new Appointment();
		assertThrows(IllegalArgumentException.class,() -> appt.updateDescription(null));
		assertThrows(IllegalArgumentException.class,() -> appt.updateDescription(tooLongDescription));
		appt.updateDescription(description);assertEquals(description, appt.getDescription());
	}
	
	@Test
	void testGetDescription() {
		Appointment appt = new Appointment(id, date, description);
		assertNotNull(appt.getDescription());
		assertTrue(appt.getDescription().length() <= 50);
		assertEquals(description, appt.getDescription());
	}
	
}	
	
	






/*	
	// Checks if appointmentId is valid length
	@Test
	void testGetAppointmentId() {
		futureDate = Date(2025,Calendar.MAY,4);
		pastDate = Date(2021, Calendar.JANUARY,31);
		
		Appointment appt = new Appointment("1234567890", futureDate, "This appointment is for financial planning.");
		assertThrows(IllegalArgumentException.class, () -> appt.getAppointmentId());
		// Sets Appointment ID as too long
		assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentId("12345678911"));
		appt.setAppointmentId("1234567890");
		assertEquals("1234567890", appt.getAppointmentId());}  
	
	private Date Date(int i, int october, int j) {
		return null;
	}
	
	@Test
    void testAppointmentIdIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Appointment(null, futureDate, "This appointment is for financial planning.");
    	});
	}
	
	// Checks whether appointment date is not before current day
	@Test
	void testSetDate() {
		futureDate = Date(2025,Calendar.MAY, 4);
		pastDate = Date(2021, Calendar.JANUARY,31);
		
		Appointment appt = new Appointment("123456789", pastDate, "This appointment is for financial planning.");
		assertThrows(IllegalArgumentException.class, () ->appt.setAppointmentDate(pastDate));
		assertThrows(IllegalArgumentException.class,() -> appt.setAppointmentDate(pastDate));
		appt.setAppointmentDate(pastDate);
		assertEquals(pastDate, appt.getAppointmentDate());
	}
	
	// Verifies that appointment date is valid
	@Test
	void testGetAppointmentDate() {
			Appointment appt = new Appointment("123456789", futureDate, "This appointment is for financial planning.");
		assertNotNull(appt.getAppointmentDate());
		assertEquals(futureDate, appt.getAppointmentDate());
	}	
	
	@Test
    void testAppointmentDescriptionIsNull( ) {
    	Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		new Appointment("1234567890", futureDate, null);
    	});
	}
	
	@Test
	void testAppointmemtDescriptionIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Appointment("1234567890", futureDate, "This appointment is for financial and retirement planning.");
		});
	}

*/
