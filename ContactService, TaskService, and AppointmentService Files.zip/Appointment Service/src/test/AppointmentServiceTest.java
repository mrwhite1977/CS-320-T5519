package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import appointment.Appointment;
import appointment.AppointmentService;

class AppointmentServiceTest {
	
	private String id, description, tooLongDescription; 
	private Date date, pastDate;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	void setUp() {
		id = "1234567890";
		description = "This appointment is for retirement planning.";
		date = new Date(2024, Calendar.JANUARY, 1);
		tooLongDescription = "This description is too long for the appointment requirement and should throw an exception.";
		pastDate = new Date(0);
	}
	
	@Test
	void testNewAppointment() {
		AppointmentService service = new AppointmentService();
		service.newAppointment(date);
		assertNotNull(service.getAppointmentList().get(0).getAppointmentId());
		assertNotNull(service.getAppointmentList().get(0).getAppointmentDate());
		assertNotNull(service.getAppointmentList().get(0).getDescription());
		
		service.newAppointment(date);
		assertNotNull(service.getAppointmentList().get(1).getAppointmentId());
		assertEquals(date, service.getAppointmentList().get(1).getAppointmentDate());
		assertNotNull(service.getAppointmentList().get(1).getDescription());
		
		service.newAppointment(date, description);
		assertNotNull(service.getAppointmentList().get(2).getAppointmentId());
		assertEquals(date,service.getAppointmentList().get(2).getAppointmentDate());
		assertEquals(description,service.getAppointmentList().get(2).getDescription());
		
		assertThrows(IllegalArgumentException.class, () ->service.newAppointment(pastDate));
		assertThrows(IllegalArgumentException.class,() ->service.newAppointment(date, tooLongDescription));
	}

	@Test
	void deleteAppointment() throws Exception {
		AppointmentService service = new AppointmentService();
		
		service.newAppointment();
		service.newAppointment();
		service.newAppointment();
		
		String firstId =service.getAppointmentList().get(0).getAppointmentId();
		String secondId =service.getAppointmentList().get(1).getAppointmentId();
		String thirdId =service.getAppointmentList().get(2).getAppointmentId();
		
		assertNotEquals(firstId, secondId);
		assertNotEquals(firstId, thirdId);
		assertNotEquals(secondId, thirdId);
		assertNotEquals(id, firstId);
		assertNotEquals(id, secondId);
		assertNotEquals(id, thirdId);
		
		assertThrows(Exception.class, () -> service.deleteAppointment(id));
		
		service.deleteAppointment(firstId);
		assertThrows(Exception.class, () ->service.deleteAppointment(firstId));
		assertNotEquals(firstId,service.getAppointmentList().get(0).getAppointmentId());
		}
	
}	







	/*
	@Test
    public void testAddAppointment() {
		
        AppointmentService as = new AppointmentService();
        Appointment test1 = new Appointment("1234567890", date, "This appointment is for retirement planning.");
        assertEquals(true, as.addAppointment(test1));
    }
	
	@Test
    public void testDeleteAppointment() {
   
        String description = "This appointment is for financial planning.";
        
        AppointmentService as = new AppointmentService();

        Appointment test1 = new Appointment("1234567890", date, description);
        Appointment test2 = new Appointment("12345678909", date, description);
        Appointment test3 = new Appointment("1234567890", date, description);

        as.addAppointment(test1);
        as.addAppointment(test2);
        as.addAppointment(test3);

        assertEquals(true, as.deleteAppointment("1234567890"));
        assertEquals(false, as.deleteAppointment("1234567899"));
        assertEquals(false, as.deleteAppointment("1234567890"));
	}
} */
