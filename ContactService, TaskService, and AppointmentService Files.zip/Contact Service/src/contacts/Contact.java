// @author Micheal White
// @Date: May 20, 2023
// CS-320-T5519

package contacts;

public class Contact {
	
	private String contactId;
	private String firstName;
	private String lastName;
	private String Number;
	private String Address;
	
	// Constructor
	public Contact(String contactId, String firstName, String lastName, String Number, String Address) {
		if(contactId == null || contactId.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		if(firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid first name");
		}
			
		if(lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		
		if(Number == null || Number.length()>10) {
			throw new IllegalArgumentException("Invalid number");
		}
		
		if(Address == null || Address.length()>30) {
			throw new IllegalArgumentException("Invalid address");
		}
		
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.Number = Number;
		this.Address = Address;
	}
	
	// Getter and setter for contactId
	public String getContactId() { 
		return contactId; 
	} 
	
	public void setContactId(String contactId) { 
		this.contactId = contactId; 
	}
	
	/*Verify contactId requirements test
	public boolean validatecontactId(String contactId) {
		if (contactId.length()<= 10 && contactId != null)
			return true;
		return false;
	}*/
	
	// Getter and setter for FirstName
	public String getFirstName() { 
		return firstName; 
	} 
		
	public void setFirstName(String firstName) { 
		this.firstName = firstName; 
	}
	
	/* Verify firstName requirements test
	public boolean validateFirstName(String firstName) {
		if (firstName.length()<= 10 && firstName != null)
			return true;
		return false;
	}*/
			
	// Getter and setter for LastName
	public String getLastName() { 
		return lastName; 
	} 
			
	public void setLastName(String lastName) { 
		this.lastName = lastName; 
	}
		
	/* Verify lastName requirements test
	public boolean validateLastName(String lastName) {
		if (lastName.length()<= 10 && lastName != null)
			return true;
		return false;
	}*/

	// Getter and setter for number
	public String getnumber() { 
		return Number; 
	} 
				
	public void setnumber(String Number) { 
		this.Number = Number; 
	}
			
	/* Verify Number requirements test
	public boolean validatenumber(String Number) {
		if (Number.length()== 10 && Number != null)
			return true;
		return false;
	}*/
	
	// Getter and setter for Address
	public String getaddress() { 
		return Address; 
	} 
				
	public void setaddress(String Address) { 
		this.Address = Address; 
	}
			
	/* Verify Address requirements test
	public boolean validateaddress(String Address) {
		if (Address.length()<= 30 && Address != null)
			return true;
		return false;
	}*/

}