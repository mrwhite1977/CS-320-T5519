// @author Micheal White
// @Date: May 27, 2023
// CS-320-T5519
package task;

import java.util.ArrayList;

public class TaskService {
	
	// Create array to hold list of contacts
		private ArrayList<Task> taskList;
		
		public TaskService() {
			taskList = new ArrayList<>();
		}
	
	// Adding a task
	public boolean addTask(Task task) {
	boolean taskExist = false;
			
		// Checks if contact exist
		for(Task l:taskList) {
			if(l.equals(task)) {
				taskExist = true; 
			}
		}
			
		// If no task exists, one will be added
		if(!taskExist) {
			taskList.add(task);
			return true;
		}
		
		else {
			return false;
		} 
	}
	
	// Deleting a task
		public boolean deleteTask(String taskId) {
			
			//	Check if task Id exist. If so, will remove and return
			for(Task l:taskList) {
				if(l.getTaskId().equals(taskId)) {
					taskList.remove(l);
					return true;
				}
			}
			
			// Otherwise will return false
			return false;
		}
		
	// Update task information if conditions are met
	public boolean updateTask(String taskId, String name, String description) {
	    // Run through loop again
		for (Task taskList : taskList) {
	        // If taskID matches, run through each with making sure not null and meets requirements
	        // Then return true since it did equal update
			if (taskList.getTaskId().equals(taskId)) {
				if (!name.equals("") && !(name.length() > 20)) {
					taskList.setName(name);
	            }
	            if (!description.equals("") && !(description.length() > 50)) {
	            	taskList.setDescription(description);
	            }
	               
	            return true;
	        }
	    }
	    //else return false
	    return false;
	}

}
