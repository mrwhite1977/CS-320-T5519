package appointment;

import java.util.Date;

public class Appointment {
	
	final private byte APPOINTMENT_ID_LENGTH;
	final private byte APPOINTMENT_DESCRIPTION_LENGTH;
	final private String INITIALIZER;
	private String appointmentId;
	private Date appointmentDate;
	private String description; {
	
		APPOINTMENT_ID_LENGTH = 10;
		APPOINTMENT_DESCRIPTION_LENGTH = 50;
		INITIALIZER = "INITIAL";
		}
	
	public Appointment() {
		Date today = new Date();
		appointmentId = INITIALIZER;
		appointmentDate = today;
		description = INITIALIZER;
	}
	
	public Appointment(String appId) {
		Date today = new Date();
		updateAppointmentId(appId);
		appointmentDate = today;
		description = INITIALIZER;
	}
	
	public Appointment(String appId, Date date) {
		updateAppointmentId(appId);
		updateDate(date);
		description = INITIALIZER;
	}
	
	public Appointment(String appId, Date date, String description) {
		updateAppointmentId(appId);
		updateDate(date);
		updateDescription(description);
	}
	
	public void updateAppointmentId(String id) {
		if (id == null) {
			throw new IllegalArgumentException("Appointment ID cannot be null.");
			}
		else if (id.length() > APPOINTMENT_ID_LENGTH) {
			throw new IllegalArgumentException("Appointment ID cannot exceed " +APPOINTMENT_ID_LENGTH +" characters.");
		}
	    
		else {
	    	this.appointmentId = id;
	    }
	}
	
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public void updateDate(Date date) {
		if (date == null) {
			throw new IllegalArgumentException("Appointment date cannot be null.");
		} else if (date.before(new Date())) {
			throw new IllegalArgumentException("Cannot make appointment in the past.");
		}
		
		else {
			this.appointmentDate = date;
		}
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public void updateDescription(String description) {
		if (description == null) {
			throw new IllegalArgumentException("Appointment description cannot be null.");
		} else if (description.length() > APPOINTMENT_DESCRIPTION_LENGTH) {
			throw new IllegalArgumentException("Appointment description cannot exceed " + 
												APPOINTMENT_DESCRIPTION_LENGTH + " characters.");
		}
		
		else {
			this.description = description;
		}
	}
		
	public String getDescription() {
		return description; 
	}
}










/*
	// The requirements for appointmentId to not be null and not be more than 10 characters in length
	// Otherwise, an exception will be thrown
	public Appointment(String apptId, Date apptDate, String apptDescript) {
		
			Date date = new Date();
		
		if(apptId == null || apptId.length() > 10) {
			// This will test for appointment ID exception
			throw new IllegalArgumentException("Invalid input");
		}	
		
		// Checks if date is null and not before current date
		if(apptDate == null || apptDate.before(date)) {
			throw new IllegalArgumentException("Invalid date");
		}
		
		
		// Checks for valid description length
		if(apptDescript == null || apptDescript.length() > 50) {
			throw new IllegalArgumentException("Invalid description");
		} 
		
		this.setAppointmentId(apptId);
		this.setAppointmentDate(apptDate);
		this.setDescription(apptDescript);
	}
	
	// Getters for each variable
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getDescription() {
		return description;
	}

	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}

	// Setters for variables
	public void setAppointmentID(String apptId) {
		if(apptId == null || apptId.length() > 10) {
			throw new IllegalArgumentException("Invalid appointment id - nullor length > 10");
		}
		
		else {this.appointmentId = apptId;
		}
	}
	public void setAppointmentDate(Date apptDate) {
		
		Date date = new Date();
		if(apptDate == null || apptDate.before(date)) {
			throw new IllegalArgumentException("Invalid date");
		}
		
		else {this.appointmentDate = apptDate;
		}
	}
	
	public void setDescription(String apptDescript) {
		if(apptDescript == null || apptDescript.length() > 10) {
			throw new IllegalArgumentException("Invalid appointment ID.");
		}
		
		else {this.description = apptDescript;
		}
	} */
