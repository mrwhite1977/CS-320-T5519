package contacts;

import java.util.ArrayList;

// Class to contain list of contacts and has ability to add, delete, and 
// update information including first name, last name, phone number and address.
public class ContactService {
	
	// Create array to hold list of contacts
	private ArrayList<Contact> contactList;
	
	public ContactService() {
		contactList = new ArrayList<>();
	}
	
	// Adding a contact
	public boolean addContact(Contact contact) {
		boolean contactExist = false;
		
		// Checks if contact exist
		for(Contact l:contactList) {
			if(l.equals(contact)) {
				contactExist = true; 
			}
		}
		
		// If no contact, one will be added
		if(!contactExist) {
			contactList.add(contact);
			return true;
		}
		
		else {
			return false;
		} 
	}
	
	// Deleting a contact
	public boolean deleteContact(String contactId) {
		
		//	Check if contact Id exist. If so, will remove and return
		for(Contact l:contactList) {
			if(l.getContactId().equals(contactId)) {
				contactList.remove(l);
				return true;
			}
		}
		
		// Otherwise will return false
		return false;
	}
	
	// Update contact information if conditions are met
	public boolean updateContact(String contactId, String firstName, String lastName, String Number,
            String Address) {
        // Run through loop again
        for (Contact contactList : contactList) {
            // If contactID matches, run through each with making sure not null and meets requirements
            // Then return true since it did equal update
            if (contactList.getContactId().equals(contactId)) {
                if (!firstName.equals("") && !(firstName.length() > 10)) {
                    contactList.setFirstName(firstName);
                }
                if (!lastName.equals("") && !(lastName.length() > 10)) {
                    contactList.setFirstName(lastName);
                }
                if (!Number.equals("") && (Number.length() == 10)) {
                    contactList.setFirstName(Number);
                }
                if (!Address.equals("") && !(Address.length() > 30)) {
                    contactList.setFirstName(Address);
                }
                return true;
            }
        }
        //else return false
        return false;
    }

}
