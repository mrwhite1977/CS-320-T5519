package test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;

import contacts.Contact;
import contacts.ContactService;

public class ContactServiceTest {

	// To test the ContactService class
	// Tests to add, delete, and update contacts
    // Contact test templates
    /*
    * Contact("1357900", "Sophia", "Petrillo", "3056838353", "6151 Richmond Street");
      Contact("2460100", "Homer", "Simpson", "5415553226", "742 Evergreen Terrace");
      Contact("0000001", "Henry", "Creel", "5556660001", "The Upside Down");
    */

    @Test
    public void testAdd() {
        ContactService cs = new ContactService();
        Contact test1 = new Contact("1357900", "Sophia", "Petrillo", "3056838353", "6151 Richmond Street");
        assertEquals(true, cs.addContact(test1));
    }

    @Test
    public void testDelete() {
        ContactService cs = new ContactService();

        Contact test1 = new Contact("1357900", "Sophia", "Petrillo", "3056838353", "6151 Richmond Street");
        Contact test2 = new Contact("2460100", "Homer", "Simpson", "5415553226", "742 Evergreen Terrace");
        Contact test3 = new Contact("0000001", "Henry", "Creel", "5556660001", "The Upside Down");

        cs.addContact(test1);
        cs.addContact(test2);
        cs.addContact(test3);

        assertEquals(true, cs.deleteContact("1357900"));
        assertEquals(false, cs.deleteContact("1357901"));
        assertEquals(false, cs.deleteContact("1357900"));
    }

    @Test
    public void testUpdate() {
        ContactService cs = new ContactService();

        Contact test1 = new Contact("1357900", "Sophia", "Petrillo", "3056838353", "6151 Richmond Street");
        Contact test2 = new Contact("2460100", "Homer", "Simpson", "5415553226", "742 Evergreen Terrace");
        Contact test3 = new Contact("0000001", "Henry", "Creel", "5556660001", "The Upside Down");

        cs.addContact(test1);
        cs.addContact(test2);
        cs.addContact(test3);

        assertEquals(true, cs.updateContact("2460100", "HomerFirst", "SimpsonLast", "5415553226", "742 Evergreen Terrace"));
        assertEquals(false, cs.updateContact("2460134", "HomerFirst", "SimpsonLast", "5415553226", "742 Evergreen Terrace"));
    }

}

